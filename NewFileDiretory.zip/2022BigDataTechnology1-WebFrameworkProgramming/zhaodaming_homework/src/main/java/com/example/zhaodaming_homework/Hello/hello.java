package com.example.zhaodaming_homework.Hello;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class hello {
    @GetMapping
    public String hello() {
        return "hello world!";
    }
}
