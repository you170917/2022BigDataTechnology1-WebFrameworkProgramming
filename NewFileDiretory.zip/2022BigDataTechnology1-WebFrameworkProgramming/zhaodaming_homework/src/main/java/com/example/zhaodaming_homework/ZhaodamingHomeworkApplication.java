package com.example.zhaodaming_homework;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZhaodamingHomeworkApplication {

    public static void main(String[] args) {
        SpringApplication.run(ZhaodamingHomeworkApplication.class, args);
    }

}
